class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def addTwoNumbers(l1: ListNode, l2: ListNode) -> ListNode:
    dummy_head = ListNode(0)
    current = dummy_head
    carry = 0

    while l1 or l2 or carry:
        val1 = l1.val if l1 else 0
        val2 = l2.val if l2 else 0
        total = val1 + val2 + carry
        carry = total // 10
        current.next = ListNode(total % 10)

        current = current.next
        if l1:
            l1 = l1.next
        if l2:
            l2 = l2.next

    return dummy_head.next

# 辅助函数：将输入的数字列表转换为链表
def to_linked_list(lst):
    head = current = ListNode(lst[0])
    for num in lst[1:]:
        current.next = ListNode(num)
        current = current.next
    return head

# 辅助函数：将链表转换为输出的数字列表
def to_list(node):
    result = []
    while node:
        result.append(node.val)
        node = node.next
    return result

# 主函数：接收用户输入并输出结果
def main():
    # 获取用户输入
    l1 = list(map(int, input("（以空格分隔）l1 = ").split()))
    l2 = list(map(int, input("（以空格分隔）l2 = ").split()))

    # 转换为链表
    l1_linked = to_linked_list(l1)
    l2_linked = to_linked_list(l2)

    # 计算链表之和
    result = addTwoNumbers(l1_linked, l2_linked)

    # 转换结果为列表并输出
    print("结果链表为:", to_list(result))

# 运行主函数
if __name__ == "__main__":
    main()
