name = []  # 创建一个空的列表 name

name.append('Lihua')  # 将 'Lihua' 添加到列表 name 中
name.append('Rain')   # 将 'Rain' 添加到列表 name 中
name.append('Jack')   # 将 'Jack' 添加到列表 name 中
name.append('Xiuxiu') # 将 'Xiuxiu' 添加到列表 name 中
name.append('Peiqi')  # 将 'Peiqi' 添加到列表 name 中
name.append('Black')  # 将 'Black' 添加到列表 name 中

name.insert(name.index('Black'), 'Blue')  # 找到 'Black' 的索引位置，然后在该位置之前插入 'Blue'
name.insert(name.index('Black') + 1, 'White')  # 找到 'Black' 的索引位置，然后在该位置之后插入 'White'
name[name.index('Xiuxiu')] = '秀秀'  # 将列表中 'Xiuxiu' 替换为 '秀秀'
numList = [1, 2, 3, 4, 2, 5, 6, 2]  # 创建一个包含数字的列表 numList
name.extend(numList)  # 将 numList 中的所有元素添加到 name 列表的末尾
print(name)  # 打印合并后的列表
temp = name[2:11:2]  # 切片操作，从索引 2 到 11 的元素，每隔 2 个取一个
print(temp)  # 打印切片后的列表
