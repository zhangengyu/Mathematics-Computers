if __name__ == '__main__':  
    str1 = open("C:\\Users\\詹耿羽\\Desktop\\test1.txt").read()  # 读取文件text1.txt的内容
    str2 = open("C:\\Users\\詹耿羽\\Desktop\\test2.txt").read()  # 读取文件text2.txt的内容
    f = open("C:\\Users\\詹耿羽\\Desktop\\test3.txt", 'w')  # 以写模式打开文件text3.txt

    # 合并字符串并进行排序：
    # 排序规则: 1. 按字符的小写字母顺序排序（忽略大小写）
    #           2. 按字符的大小写顺序（大写字母排在小写字母之前）
    f.write(''.join(sorted(str1 + str2, key=lambda x: (x.lower(), x))))  # 合并str1和str2并排序后写入文件
    f.close()  # 关闭文件，确保写入完成

    print(u'txt3写入成功')  # 输出'文件写入成功'的提示信息
